<html>
<head>
        <title>My Blog</title>
</head>
<body>
        <h1>Welcome to my Blog!</h1>

<?php
	  echo '<h1>'.$name.'</h1>';
	  echo '<h1>'.$age.'</h1>';



	  /******************** ARRAY HELPER *****************************/
 
 $this->load->helper('array');
	  $arr = array(

	  	"name"=> "Rahul",
	  	"age"=> 20,
	  	"location"=>"Mulund"

	  );

	  
	  print_r($arr);
	  echo '<br>';

	  echo element("name", $arr).'<br>';

	  echo element('size', $arr, 'foobar').'<br>';

$my_data = elements(array('name', 'age', 'location'), $arr);

print_r($my_data);
echo '<br>';



$quotes = array(
        "I find that the harder I work, the more luck I seem to have. - Thomas Jefferson",
        "Don't stay in bed, unless you can make money in bed. - George Burns",
        "We didn't lose the game; we just ran out of time. - Vince Lombardi",
        "If everything seems under control, you're not going fast enough. - Mario Andretti",
        "Reality is merely an illusion, albeit a very persistent one. - Albert Einstein",
        "Chance favors the prepared mind - Louis Pasteur"
);

echo random_element($quotes);

echo "<br>";

 /******************** CAPTCHA HELPER *****************************/
 $this->load->helper('captcha');

 $vals = array(
        'word'          => '',
        'img_path'      => './captcha/',
        'img_url'       => 'http://localhost/rahul/CodeIgniter/captcha/',
        'font_path'     => './path/to/fonts/texb.ttf',
        'img_width'     => '150',
        'img_height'    => 30,
        'expiration'    => 7200,
        'word_length'   => 8,
        'font_size'     => 16,
        'img_id'        => 'Imageid',
        'pool'          => '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',

        // White background and border, black text and red grid
        'colors'        => array(
                'background' => array(255, 255, 255),
                'border' => array(255, 255, 255),
                'text' => array(0, 0, 0),
                'grid' => array(255, 40, 40)
        )
);

$cap = create_captcha($vals);
echo $cap['image'];



/******************** FORM HELPER *****************************/
$this->load->helper('form');

echo form_open('email/send');
echo form_hidden('username');
echo form_input('email','');
echo form_password('password','');
echo form_upload('images','');
echo form_textarea('message','test');
echo form_checkbox('newsletter', 'accept', TRUE);
echo form_submit('mysubmit', 'Submit Post!');

$options = array(
        'small'         => 'Small Shirt',
        'med'           => 'Medium Shirt',
        'large'         => 'Large Shirt',
        'xlarge'        => 'Extra Large Shirt',
);

$shirts_on_sale = array('small', 'large');
echo form_dropdown('shirts', $options, 'large');


$attributes = array(
        'class' => 'mycustomclass',
        'style' => 'color: #000;'
);

echo form_label('What is your Name', 'username', $attributes);

echo form_close();
echo "<br>";

/******************** DIRECTORY HELPER *****************************/
$this->load->helper('directory');
$map = directory_map('./captcha/');
print_r($map);


/******************** SECURITY HELPER *****************************/
$this->load->helper('security');
echo '<br>';
$str = do_hash("abcd") . '<br>';// SHA1
echo $str;
$str1 = do_hash("abcd", 'md5'); // MD5
echo $str1;

/******************** HTML HELPER *****************************/
$this->load->helper('html');
echo heading('Welcome!', 3, 'class="pink"');
echo heading('How are you?', 4, array('id' => 'question', 'class' => 'green'));



/******************** TEXT HELPER *****************************/
$this->load->helper('text');

$string = "Here is a nice text string consisting of eleven words.";
$string = word_limiter($string, 7);
echo $string;


$string = highlight_code($string);
echo $string; // Returns:  Here is a nice


/******************** URL HELPER *****************************/
$this->load->helper('url');
$segments = array('news', 'local', '123');
echo site_url($segments);

?>
</body>
</html>