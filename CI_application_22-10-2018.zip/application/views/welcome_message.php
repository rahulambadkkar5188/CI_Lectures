<html>
<head>
        <title>My Page</title>
</head>
<body>
        <h1>Welcome!</h1>
</body>
</html>