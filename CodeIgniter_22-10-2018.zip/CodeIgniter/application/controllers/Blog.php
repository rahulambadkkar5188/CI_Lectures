<?php
class Blog extends CI_Controller
{
	public function index(){
		echo "Blog Controller TEST";
	}
	public function comments(){
		echo "Comments function TEST";
	}
	public function shoes($sandals, $id)
    {
            echo $sandals;
            echo $id;
            // URL: http://localhost/rahul/CodeIgniter/index.php/Blog/shoes/shoes/123
    }
}

	

?>