<?php
  class Project extends CI_Controller{
  	function index()
  	{
  		$this->load->view('project_view');
  	}

  	function actionPage()
  	{
  		//echo "TEST";

		$this->form_validation->set_rules('username', 'Person Name', 'required|alpha|min_length[5]|max_length[12]');

		$this->form_validation->set_rules('userage', 'Person Age', 'required|integer|less_than[100]|greater_than[0]');


		if($this->form_validation->run() == FALSE)
		{
			//echo "ERROR";
			$this->load->view('project_view');
		}
		else{
			print_r($_POST);
  		$res = $this->input->post("userage");
  		print_r($res);
  	
		}

	}
  }
?>