<?php
  echo "Action page";
?>