<?php
echo validation_errors();
 echo form_open('project/actionPage');

 
?>
<ul>
	<li>Name:</li>
	<li><?php echo form_input('username',"");?></li>
	<li>Age:</li>
	<li><?php echo form_input('userage',20);?></li>
	<li><?php echo form_submit('',"Add");?></li>
</ul>
<?php
 echo form_close();
?>