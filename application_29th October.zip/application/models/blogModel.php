<?php
/**/
class blogModel extends CI_Model
{
	
	function insertData($res1,$res2)
	{
		//echo "test";

		$data = array(
        'username' => $res1,
        'userage' => $res2
);

		//$result = $this->db->insert('userrecord',$data);

		$result = $this->db->query("insert into userrecord (username,userage) values('$res1','$res2')");
		var_dump($result);
		return $result;
	}
	
	
}


?>