<?php
echo validation_errors();
 echo form_open('blog/actionPage');
 
?>
<ul>
        <li>Name:</li>
        <li><?php echo form_input('username',$data1);?></li>
        <li>Age:</li>
        <li><?php echo form_input('userage',$data2);?></li>
        <li><?php echo form_submit('',"Submit");?></li>
</ul>
<?php
 echo form_close();
?>