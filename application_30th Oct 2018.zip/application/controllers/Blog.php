<?php
  class Blog extends CI_Controller{
    function index()
    {
      $this->load->view('blogview');
    }

    function actionPage()
    {
      //echo "TEST";

    $this->form_validation->set_rules('username', 'Person Name', 'required|alpha|min_length[5]|max_length[12]|is_unique[userrecord.username]');

    $this->form_validation->set_rules('userage', 'Person Age', 'required|integer|less_than[100]|greater_than[0]');


    if($this->form_validation->run() == FALSE)
    {
      //echo "ERROR";
      $this->load->view('blogview');
    }
    else{
      //print_r($_POST);
      $res1 = $this->input->post("username");
      $res2 = $this->input->post("userage");
      

      $this->load->model('blogModel');
      $this->blogModel->insertData($res1,$res2);
    
    }

  }


	  function file_upload()
	  {
	  	$this->load->view('file_upload_view');
	  }
	  function file_action()
	  {
	  		print_r($_POST);
	  		print_r($_FILES);

	  		$res1 = $this->input->post('username');
	  		$res2 = $this->input->post('userage');

	  		$config['upload_path']          = './uploads/';
            $config['allowed_types']        = 'gif|jpg|png';
            $config['max_size']             = 100;
            $config['max_width']            = 1024;
            $config['max_height']           = 768;
            $config['file_ext_tolower']     = TRUE;
            $config['remove_spaces']        = TRUE;

            //$this->load->library('upload', $config);
            $this->upload->initialize($config);

            $path = time(). $_FILES['userimage']['name'];
            $_FILES['userimage']['name'] = $path;

            if ( ! $this->upload->do_upload('userimage'))
                {
                        $error = array('error' => $this->upload->display_errors());

                       // $this->load->view('upload_form', $error);
                        print_r($error);
                }
                else
                {
                		$this->load->model('blogModel');
                		$this->blogModel->addUserImage($res1,$res2,$path);
                        /*$data = array('upload_data' => $this->upload->data());

                        $this->load->view('upload_success', $data);*/

                        echo "File Upload Success";
                }

	  		
	  }


	  function session1(){
	  	$this->session->set_userdata('name','rahul');
	  	$this->session->set_userdata('email','rahul@gmail.com');


	  	$newdata = array(
        'age'  => '24',
        'mobile'     => 9004231392,
        'logged_in' => TRUE
);

		$this->session->set_userdata($newdata);
		redirect(base_url('index.php/blog/session2'));
	  }
	  function session2(){
	  	$this->load->view('show_sesion_data');
	  }

	  function session3(){
	  	$this->session->unset_userdata('name');
	  	$this->session->unset_userdata('mobile');
	  	$this->session->unset_userdata('age');
	  	$this->session->unset_userdata('email');
	  	$this->session->sess_destroy();
	  	redirect(base_url());
	  }
  }
?>