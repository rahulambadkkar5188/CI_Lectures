<?php
  class Project extends CI_Controller{
    function index()
    {
      $this->load->view('project_view');
    }

    function actionPage()
    {
      //echo "TEST";

    $this->form_validation->set_rules('username', 'Person Name', 'required|alpha|min_length[5]|max_length[12]|is_unique[userrecord.username]');

    $this->form_validation->set_rules('userage', 'Person Age', 'required|integer|less_than[100]|greater_than[0]');


    if($this->form_validation->run() == FALSE)
    {
      //echo "ERROR";
      $this->load->view('project_view');
    }
    else{
      //print_r($_POST);
      $res1 = $this->input->post("username");
      $res2 = $this->input->post("userage");
      

      $this->load->model('blogModel');
      $this->blogModel->insertData($res1,$res2);
    
    }

  }
  }
?>