<?php
class Userrecord extends CI_Controller
{
	public function index(){
		echo "TEST";
		$this->load->view('blogview');
	}
}

?>