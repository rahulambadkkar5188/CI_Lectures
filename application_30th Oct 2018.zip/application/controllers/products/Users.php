<?php
class Users extends CI_Controller
{
	public function index(){
		echo "Users Controller TEST";
	}
	public function comments(){
		echo "Comments function TEST";
	}
	public function shoes($sandals, $id)
    {
            echo $sandals;
            echo $id;
            // URL: http://localhost/rahul/CodeIgniter/index.php/Blog/shoes/shoes/123
    }
}

	

?>