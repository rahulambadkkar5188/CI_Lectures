<?php
  function show(){
  	echo "<h1>Welcome to My Helper</h1>";
  }

?>