<?php
/**/
class blogModel extends CI_Model
{
	
	function insertData($res1,$res2,$res3)
	{
		//echo "test";

		$data = array(
        'username' => $res1,
        'userage' => $res2
		);

		//$result = $this->db->insert('userrecord',$data);

		$result = $this->db->query("insert into userrecord (username,userage) values('$res1','$res2')");
		var_dump($result);
		echo "<br><b>Data Inserted successfuly.</b>";
		return $result;
	}
	function addUserImage($res1,$res2,$path)
	{
		$data = array(
        'username' => $res1,
        'userage' => $res2,
        'userimage' => $path
		);

		//$result = $this->db->insert('userrecord',$data);

		$result = $this->db->query("insert into userrecord (username,userage,userimage) values('$res1','$res2','$path')");
		var_dump($result);
		echo "<br><b>Data Inserted successfuly.</b>";
		return $result;
	}
}


?>