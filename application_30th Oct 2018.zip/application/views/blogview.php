<?php
echo validation_errors();
 echo form_open_multipart('blog/file_action');
 
?>
<ul>
        <li>Name:</li>
        <li><?php echo form_input('username',"");?></li>
        <li>Age:</li>
        <li><?php echo form_input('userage',"");?></li>
        <li>Upload Profile Image:</li>
        <li><?php echo form_upload('userimage',"");?></li>
        <li><?php echo form_submit('',"Add");?></li>
</ul>
<?php
$this->load->view('footer');
 echo form_close();
 //func1();
?>