<?php
// $this->load->helper('url');
?>


<a href="<?php echo base_url();?>index.php/blog/show/">Show Data</a>
<a href="<?php echo base_url();?>index.php/blog/actionPage/">Add User</a>
<a href="<?php echo base_url();?>index.php/blog/file_upload/">Upload file</a>
<a href="<?php echo base_url();?>index.php/blog/session1/">Set Session</a>
<a href="<?php echo base_url();?>index.php/blog/session2/">View Session</a>
<a href="<?php echo base_url();?>index.php/blog/session3/">Destory Session</a>