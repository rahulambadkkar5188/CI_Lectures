
<h2>SESSION DATA</h2>
<?php
  $name = $this->session->userdata('name');
  echo $name;
?>

<a href="<?php echo base_url();?>index.php/blog/session3/">LOGOUT</a>