<?php
  $name = $_POST['prod_name'];
  $description = $_POST['prod_desc'];
  $price = $_POST['prod_price'];

    $conn = mysqli_connect("localhost","root","","rahul_cart");

    $sql = "INSERT INTO products (name,description,price) VALUES('$name','$description','$price')";

    $result = mysqli_query($conn,$sql);

   // $row = mysqli_num_assoc($result);
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Vertical (basic) form</h2>
  <form action="add_product.php" method="POST" enctype="text/multipart-form">
    <div class="form-group">
      <label for="prod_name"> Product Name:</label>
      <input type="text" class="form-control" id="prod_name" placeholder="Enter product name" name="prod_name">
    </div>
    <div class="form-group">
      <label for="prod_desc">Product Description:</label>
      <input type="text" class="form-control" id="prod_desc" placeholder="Enter description" name="prod_desc">
    </div>
    <div class="form-group">
      <label for="prod_price">Product Price:</label>
      <input type="number" class="form-control" id="prod_price" placeholder="Enter product price" name="prod_price">
    </div>
    
    <button type="submit" class="btn btn-default">Submit</button>
  </form>
</div>

</body>
</html>