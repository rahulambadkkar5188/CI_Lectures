<?php
$conn = mysqli_connect("localhost","root","","rahul_cart");
   
	$id = $_POST['id'];
   
    $sql = "INSERT INTO cart (pid) VALUES ('$id') WHERE pid = '$id' ";

    $result = mysqli_query($conn,$sql);

  header("location:cart.php");

?>

