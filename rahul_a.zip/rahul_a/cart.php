<?php

	$id = $_POST['id'];

   
    $sql = "SELECT * FROM cart WHERE pid = '$id' ";

  header("location:add_to_cart.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Display product</h2>
  <table class="table table-stripped table-hover">
    <tr>
      <th>ID</th>
      <th>Name</th>
      <th>Description</th>
      <th>Price</th>
      <th>Action</th>
    </tr>

     
      <?php
        while($row = mysqli_fetch_assoc($result))
        {

          echo "<tr><td>".$row['id']."</td>";
          echo"<td>".$row['name']."</td>";
          echo "<td>".$row['description']."</td>";
          echo "<td>".$row['price']."</td>  ";
          echo "<td><a href='delete_cart?id=".$row['id']."'class='btn'>Delete</button></td>";
          echo "<td><a href='update_cart?id=".$row['id']."'class='btn'>Update</button></td>";
         }
      ?>
     

     <td colspan="6"><button type="submit" class='btn'>Proceed to payment</button></td></tr>

  
  </table>
   
</div>

</body>
</html>